public interface IConfigurationProvider<TResponse, TRequest>
{
    TResponse Get(string key, TRequest request);
}