public interface IQuickConfigProvider<TResponse, TRequest>
    : IConfigurationProvider<TResponse, TRequest>
{
}