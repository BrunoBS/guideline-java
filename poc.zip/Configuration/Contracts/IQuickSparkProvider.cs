public interface IQuickSparkProvider<TResponse, TRequest>
    : IConfigurationProvider<TResponse, TRequest>
{
}