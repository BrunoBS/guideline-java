public class ConfigurationService
{
    private readonly QuickConfigProviderResolver _quickConfigResolver;
    private readonly QuickSparkProviderResolver _quickSparkResolver;

    public ConfigurationService(
        QuickConfigProviderResolver quickConfigResolver,
        QuickSparkProviderResolver quickSparkResolver)
    {
        _quickConfigResolver = quickConfigResolver;
        _quickSparkResolver = quickSparkResolver;
    }

    public TResponse Get<TResponse, TRequest>(string key, TRequest request)
    {
        IConfigurationProvider<TResponse, TRequest>? provider =
            ConfigurationTypeHelper.IsQuickConfig(key)
                ? _quickConfigResolver.Resolve<TResponse, TRequest>()
                : _quickSparkResolver.Resolve<TResponse, TRequest>();

        if (provider is null)
            throw new InvalidOperationException("Provider não encontrado");
        return provider.Get(key, request);
    }
}