public static class ConfigurationTypeHelper
{
    public static bool IsQuickConfig(string key)
    {
        bool isQuickConfig = key.StartsWith("quickconfig", StringComparison.OrdinalIgnoreCase);
        Console.WriteLine($"Key: {key} | IsQuickConfig: {isQuickConfig}");
        return isQuickConfig;
    }
}