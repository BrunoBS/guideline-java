public class ContaRequest
{
    public string Name { get; set; }
}