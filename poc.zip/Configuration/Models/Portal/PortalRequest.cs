public class PortalRequest
{
    public string AccountId { get; set; }
}