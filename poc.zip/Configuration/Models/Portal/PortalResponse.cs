public class PortalResponse
{
    public string Theme { get; set; }

    public bool Enabled { get; set; }
}