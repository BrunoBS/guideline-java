public class PortalQuickSparkProvider: IQuickSparkProvider<PortalResponse,PortalRequest>
{
    public PortalResponse Get(
        string key,
        PortalRequest request)
    {
        return new PortalResponse
        {
            Theme = "light",
            Enabled = true
        };
    }
}