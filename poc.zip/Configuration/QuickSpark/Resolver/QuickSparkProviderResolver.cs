using Microsoft.Extensions.DependencyInjection;

public class QuickSparkProviderResolver
{
    private readonly IServiceProvider _serviceProvider;

    public QuickSparkProviderResolver(
        IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public IQuickSparkProvider<TResponse, TRequest> ? Resolve<TResponse, TRequest>()
    {
         Console.WriteLine("QuickSparkProviderResolver - Provider: {_serviceProvider.GetType().Name}");
        return _serviceProvider.GetService<
            IQuickSparkProvider<TResponse, TRequest>>();
    }
}