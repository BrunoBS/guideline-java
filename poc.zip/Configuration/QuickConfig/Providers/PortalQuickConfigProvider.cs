public class PortalQuickConfigProvider
    : IQuickConfigProvider<
        PortalResponse,
        PortalRequest>
{
    public PortalResponse Get(
        string key,
        PortalRequest request)
    {
        return new PortalResponse
        {
            Theme = "dark",
            Enabled = true
        };
    }
}