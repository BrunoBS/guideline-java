public class ContaQuickConfigProvider : IQuickConfigProvider<ContaResponse, ContaRequest>
{
    public ContaResponse Get(string key, ContaRequest request)
    {

        return new ContaResponse
        {
            Id = "1",
            Name = "conta01"
        };
    }
}