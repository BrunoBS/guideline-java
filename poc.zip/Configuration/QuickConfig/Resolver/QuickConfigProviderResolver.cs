using Microsoft.Extensions.DependencyInjection;

public class QuickConfigProviderResolver
{
    private readonly IServiceProvider _serviceProvider;

    public QuickConfigProviderResolver(
        IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public IQuickConfigProvider<TResponse, TRequest> ? Resolve<TResponse, TRequest>()
    {
        Console.WriteLine("QuickConfigProviderResolver - Provider: {_serviceProvider.GetType().Name}");

    
        return _serviceProvider.GetService<
            IQuickConfigProvider<TResponse, TRequest>>();
    }
}
