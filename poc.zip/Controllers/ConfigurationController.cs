using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("configurations")]
public class ConfigurationController : ControllerBase
{
    private readonly ConfigurationService
        _configurationService;

    public ConfigurationController(
        ConfigurationService configurationService)
    {
        _configurationService = configurationService;
    }

    [HttpGet("portal")]
    public IActionResult GetPortal(
        [FromQuery] string key,
        [FromQuery] string accountId)
    {
        var request = new PortalRequest
        {
            AccountId = accountId
        };

        var response =
            _configurationService
                .Get<PortalResponse, PortalRequest>(
                    key,
                    request);

        return Ok(response);
    }

    [HttpGet("conta")]
    public IActionResult GetConta(
        [FromQuery] string key,
        [FromQuery] string accountName
        )
    {
        var request = new ContaRequest
        {
            Name = accountName
        };

        var response =
            _configurationService
                .Get<ContaResponse, ContaRequest>(
                    key,
                    request);

        return Ok(response);
    }
}